﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LabMidQ2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Password Generator");

            string registrationNumber = "58"; 
            char firstNameSecondLetter = 'U'; 
            char lastNameSecondLetter = 'A'; 
            string favoriteMovieChars = "ME"; 
            string specialChars = "@$%&"; // Define the allowed special characters

            string pattern = $"[{registrationNumber}][{firstNameSecondLetter}][{lastNameSecondLetter}][{favoriteMovieChars}][{specialChars}]{{8}}";

            string password;

            password = GeneratePassword(registrationNumber, firstNameSecondLetter, lastNameSecondLetter, favoriteMovieChars, specialChars);

            Console.WriteLine("Generated Password: " + password);
        }

        private static string GeneratePassword(string regNum, char fnLetter, char lnLetter, string movieChars, string specialChars)
        {
            Random random = new Random();
            char[] password = new char[14];

            password[0] = regNum[random.Next(regNum.Length)]; 
            password[1] = fnLetter;                          
            password[2] = lnLetter;                          
            password[3] = movieChars[random.Next(movieChars.Length)]; 
            password[4] = specialChars[random.Next(specialChars.Length)]; 
            password[5] = specialChars[random.Next(specialChars.Length)]; 
            password[6] = regNum[random.Next(regNum.Length)]; 
            password[7] = movieChars[random.Next(movieChars.Length)];

         
            for (int i = 8; i < 14; i++)
            {
             
                int source = random.Next(3); 

                switch (source)
                {
                    case 0:
                        password[i] = regNum[random.Next(regNum.Length)];
                        break;
                    case 1:
                        password[i] = movieChars[random.Next(movieChars.Length)];
                        break;
                    case 2:
                        password[i] = specialChars[random.Next(specialChars.Length)];
                        break;
                }
            }
            password = password.OrderBy(x => random.Next()).ToArray();

            return new string(password);
        }
    }
    }
